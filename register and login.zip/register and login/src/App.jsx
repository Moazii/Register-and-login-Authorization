import React, { useState } from "react";
import Login from "./components/login";
import Home from "./components/home";

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(
    localStorage.getItem("LoggedIn") === "true"
  );

  const handleLogout = () => {
    localStorage.removeItem("LoggedIn");
    setIsAuthenticated(false);
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
  };
  return (
    <>
      {isAuthenticated ? (
        <div className="bg-rose-300">
          <Home onLogout={handleLogout} />
        </div>
      ) : (
        <div className="bg-rose-300">
          <Login onLogin={handleLogin} />
        </div>
      )}
    </>
  );
}

export default App;
