// src/Register.js
// src/Register.js
import React, { useState } from 'react';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = () => {
    const user = { username, password };
    localStorage.setItem('user', JSON.stringify(user));
    alert('Registration successful! You can now log in.');
  };

  return (
    <div className="card w-96 bg-base-100 shadow-xl grid place-items-center">
    <div className="card-body">
      <h2 className="text-2xl font-bold mb-6">Register</h2>
      <input
        type="text"
        placeholder="Username"
        className="input input-bordered input-accent w-full max-w-xs"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <br />

      <input
        type="password"
        placeholder="password"
        className="input input-bordered input-accent w-full max-w-xs"
        value={setPassword}
        onChange={(e) => setPassword(e.target.value)}
      />
      <br />

      <button className="btn btn-outline btn-accent w-[100%]"
        onClick={handleRegister}
      >Register</button>
   
      
    </div>
  </div>
  );
};

export default Register;
