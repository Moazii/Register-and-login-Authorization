import React, { useState } from "react";

function Login({ onLogin }) {
  const [registered, setRegistered] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = (e) => {
    e.preventDefault();
    const user = { username, password };
    localStorage.setItem("users", JSON.stringify(user));
    alert("User registered successfully");
    setRegistered(true);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const user = JSON.parse(localStorage.getItem("users"));
    if (user && user.username === username && user.password === password) {
      localStorage.setItem("loggedIn", true);
      onLogin();
      setUsername("");
      setPassword("");
    } else {
      setError("Invalid credentials");
    }
  };
  return (
    <>
      {registered ? (
        <div className="h-screen grid place-items-center">
          <div className="card w-96 bg-base-100 shadow-xl">
            <div className="card-body">
              <h1 className="text-center text-2xl font-bold mb-4">Login</h1>
              <form>
                <input
                  type="text"
                  placeholder="Name"
                  className="input input-bordered w-full max-w-xs"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
                <br />
                <br />
                <input
                  type="password"
                  placeholder="Password"
                  className="input input-bordered w-full max-w-xs"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <br />
                <br />
                <button
                  onClick={handleLogin}
                  className="btn btn-error w-[100%] text-white font-bold"
                >
                  Login
                </button>
              </form>
              {error && <p className="text-red-500">{error}</p>}
            </div>
          </div>
        </div>
      ) : (
        <div className="h-screen grid place-items-center">
          <div className="card w-96 bg-base-100 shadow-xl">
            <div className="card-body">
              <h1 className="text-center text-2xl font-bold mb-4">Register</h1>
              <form>
                <input
                  type="text"
                  placeholder="Name"
                  className="input input-bordered w-full max-w-xs"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
                <br />
                <br />
                <input
                  type="password"
                  placeholder="Password"
                  className="input input-bordered w-full max-w-xs"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <br />
                <br />
                <button
                  onClick={handleRegister}
                  className="btn btn-error w-[100%] text-white font-bold"
                >
                  Register
                </button>
              </form>
              <p>
                Already have an account?{" "}
                <a href="#" onClick={() => setRegistered(true)}>
                  Login
                </a>
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Login;
