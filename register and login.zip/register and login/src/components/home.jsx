import React from "react";

function Home({onLogout}) {
  return (
    <>
      <h1 className="text-9xl text-center">Welcome to Miracle</h1>
      <button onClick={onLogout}>LogOut</button>
    </>
  );
}

export default Home;
